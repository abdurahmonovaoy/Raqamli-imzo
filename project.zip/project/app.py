from flask import Flask, render_template, request, redirect, url_for, session, send_file
import os
import subprocess
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.exceptions import InvalidSignature
from cryptography.exceptions import InvalidSignature

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# 🟢 Fayl yo‘llarini aniqlaymiz
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Imzo faylini tekshirish uchun public key va private key
public_key_path = 'public_key.pem'
signature_path = 'signature.pem'

# 🔧 Flask configga joylaymiz
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# 🔑 Kalitlar yo‘li
private_key_path = os.path.join(BASE_DIR, 'ecdsa_private.pem')
public_key_path = os.path.join(BASE_DIR, 'ecdsa_public.pem')

# Fayl nomlari va ularning kengaytmasi
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

# Fayl kengaytmasi tekshiruvi
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Imzo tekshirish funksiyasi
def verify_signature(original_file_data, signature, public_key_bytes):
    # Imzo tekshirish logikasi (OpenSSL yoki boshqa kutubxona yordamida)
    # Bu yerda OpenSSL yordamida yoki boshqa kutubxona yordamida tekshirish amalga oshiriladi
    # Hozirgi paytda faqat namuna ko'rsatilgan
    return True  # Bu yerda to'g'ri yoki noto'g'ri tekshirish amalga oshiriladi

# 🛡️ Kalitlarni avtomatik yaratish
def generate_keys_if_not_exist():
    if not os.path.exists(private_key_path) or not os.path.exists(public_key_path):
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )
        public_key = private_key.public_key()

        # Maxfiy kalitni saqlash
        with open(private_key_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))

        # Ochiq kalitni saqlash
        with open(public_key_path, "wb") as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))

# 🔁 Har safar ishga tushganda kalitlar bo‘lmasa yaratamiz
generate_keys_if_not_exist()



@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if 'user' not in session or session['user'] != 'user1':
        return redirect(url_for('login'))

    if request.method == 'POST':
        if 'file' not in request.files:
            return "Fayl topilmadi", 400
        file = request.files['file']
        if file.filename == '':
            return "Fayl tanlanmadi", 400

        # Faylni saqlash
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)
        filepath = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filepath)

        # Fayl mazmunini o'qish
        with open(filepath, 'rb') as f:
            data = f.read()

        # RSA kalitlarini yaratish
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        public_key = private_key.public_key()

        # Faylga imzo qo‘yish
        signature = private_key.sign(
            data,
            padding.PKCS1v15(),
            hashes.SHA256()
        )

        # Imzoni saqlash
        signature_path = os.path.join(UPLOAD_FOLDER, file.filename + '.sig')
        with open(signature_path, 'wb') as sig_file:
            sig_file.write(signature)

        # Public kalitni saqlash
        public_key_path = os.path.join(UPLOAD_FOLDER, file.filename + '.pub.pem')
        with open(public_key_path, 'wb') as pub_file:
            pub_file.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))

        # Private kalitni saqlash (faqat test uchun, realda xavfsiz joyda saqlang!)
        private_key_path = os.path.join(UPLOAD_FOLDER, file.filename + '.priv.pem')
        with open(private_key_path, 'wb') as priv_file:
            priv_file.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            ))

        return f"""
         Fayl yuklandi va imzolandi!<br>
         Imzo saqlandi: {signature_path}<br>
         Jamoaviy kalit (public key): {public_key_path}<br>
         Maxfiy kalit (private key): {private_key_path}<br>
        """

    return render_template('upload.html')


if not os.path.exists(private_key_path):
    print("❌ Fayl yo‘q! Yo‘lni tekshirib ko‘ring:", private_key_path)
else:
    print("✅ Private key fayli mavjud:", private_key_path)

if not os.path.exists(public_key_path):
    print("❌ Fayl yo‘q! Yo‘lni tekshirib ko‘ring:", public_key_path)
else:
    print("✅ Public key fayli mavjud:", public_key_path)

# Yangilangan login ma'lumotlari
USERS = {
    "user1": "user1",  # Fayl yuklaydigan foydalanuvchi
    "user2": "user2"   # Fayl yuklab oladigan foydalanuvchi
}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in USERS and USERS[username] == password:
            session['user'] = username
            if username == "user1":
                return redirect(url_for('upload'))
            else:
                return redirect(url_for('download'))
        return "Invalid credentials!", 401
    return render_template('login.html')



# 🔐 Imzolash funksiyasi
def sign_data(data):
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()

    signature = private_key.sign(
        data,
        padding.PKCS1v15(),
        hashes.SHA256()
    )

    # Kalitlarni fayllarga saqlaymiz
    with open(private_key_path, 'wb') as f:
        f.write(private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption()
        ))

    with open(public_key_path, 'wb') as f:
        f.write(public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        ))

    return signature
def verify_signature(file_data, signature_data, public_key_bytes):
    public_key = serialization.load_pem_public_key(public_key_bytes)

    try:
        public_key.verify(
            signature_data,
            file_data,
            padding.PKCS1v15(),
            hashes.SHA256()
        )
        return True
    except InvalidSignature:
        return False


@app.route('/download', methods=['GET', 'POST'])
def download():
    if 'user' not in session or session['user'] != 'user2':
        return redirect(url_for('login'))

    files = [f for f in os.listdir(app.config['UPLOAD_FOLDER']) if not f.endswith(('.sig', '.pem'))]

    message = None
    status = None

    if request.method == 'POST':
        selected_file = request.form.get('filename')
        if not selected_file:
            message = "Hech qanday fayl tanlanmadi"
            status = "danger"
        else:
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], selected_file)
            signature_path = filepath + '.sig'
            public_key_path = filepath + '.pub.pem'

            if not os.path.exists(signature_path) or not os.path.exists(public_key_path):
                message = "Imzo yoki ochiq kalit topilmadi"
                status = "danger"
            else:
                with open(filepath, 'rb') as f:
                    file_data = f.read()
                with open(signature_path, 'rb') as f:
                    signature_data = f.read()
                with open(public_key_path, 'rb') as f:
                    public_key_bytes = f.read()

                is_valid = verify_signature(file_data, signature_data, public_key_bytes)

                if is_valid:
                    message = "✅ Imzo to‘g‘ri. Fayl o‘zgartirilmagan."
                    status = "success"
                else:
                    message = "❌ Imzo noto‘g‘ri! Fayl o‘zgartirilgan bo‘lishi mumkin."
                    status = "danger"

    return render_template('download.html', files=files, message=message, status=status)

@app.route('/verify_signature', methods=['POST'])
def verify_signature_route():
    if 'file' not in request.files:
        return render_template('download.html', result="❌ Fayl tanlanmadi!")

    file = request.files['file']
    if not file:
        return render_template('download.html', result="❌ Hech qanday fayl yuborilmadi!")

    filename = file.filename

    # Fayl kengaytmasini tekshirish
    if not allowed_file(filename):
        return render_template('download.html', result="❌ Noto'g'ri fayl kengaytmasi!")

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(filename))
    file.save(filepath)

    # Imzo faylini qidirish
    sig_path = filepath + '.sig'
    if not os.path.exists(sig_path):
        return render_template('download.html', result="❌ Imzo fayli topilmadi!")

    with open(filepath, 'rb') as f:
        original_file_data = f.read()
    with open(sig_path, 'rb') as f:
        signature = f.read()
    with open(public_key_path, 'rb') as f:
        public_key_bytes = f.read()

    # Imzoni tekshirish
    if verify_signature(original_file_data, signature, public_key_bytes):
        result = "✅ Imzo to‘g‘ri!"
    else:
        result = "❌ Imzo noto‘g‘ri!"

    print("Tekshirilayotgan fayl:", filepath)
    print("Imzo fayli qidirilmoqda:", sig_path)
    print("Imzo fayli mavjudmi:", os.path.exists(sig_path))

    return render_template('download.html', result=result)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
